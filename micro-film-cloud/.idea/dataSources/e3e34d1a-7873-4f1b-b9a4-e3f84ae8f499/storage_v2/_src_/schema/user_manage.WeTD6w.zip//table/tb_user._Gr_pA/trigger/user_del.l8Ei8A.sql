create definer = `skip-grants user`@`skip-grants host` trigger user_del
    after DELETE
    on tb_user
    for each row
BEGIN

     DELETE FROM tb_user_info WHERE userId=old.userId;

END;

