create definer = `skip-grants user`@`skip-grants host` trigger user_ins
    after INSERT
    on tb_user
    for each row
BEGIN 

  INSERT INTO tb_user_info (userId) value (new.userId);

END;

